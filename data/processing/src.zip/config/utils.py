import os
import datetime

from dotenv import load_dotenv

load_dotenv()

def get_env(variable_name: str, default_value=None):
    """
    Retrieve an environment variable with an optional default value.
    """
    return os.environ.get(variable_name, default_value)

def serialize(obj):
    if isinstance(obj, datetime.datetime):
        # Convert datetime to string with microsecond precision and replace "T" with a space.
        return obj.isoformat(timespec="microseconds")
    elif isinstance(obj, str):
        # If it's already a string, assume it's in ISO format and replace "T" with a space.
        return obj.replace("T", " ")
    return obj
